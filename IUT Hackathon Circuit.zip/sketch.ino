// Switch pins
const int switchPins[5] = {2, 3, 4, 5, 6};

// LED pins
const int ledPins[5] = {8, 9, 10, 11, 12};

// Stores ON/OFF state of each LED
bool ledState[5] = {false, false, false, false, false};

// Stores previous button state
bool lastButtonState[5] = {HIGH, HIGH, HIGH, HIGH, HIGH};

void setup() {

  // Switches
  for (int i = 0; i < 5; i++) {
    pinMode(switchPins[i], INPUT_PULLUP);
  }

  // LEDs
  for (int i = 0; i < 5; i++) {
    pinMode(ledPins[i], OUTPUT);
    digitalWrite(ledPins[i], LOW);
  }
}

void loop() {

  for (int i = 0; i < 5; i++) {

    bool currentState = digitalRead(switchPins[i]);

    // Detect button press (HIGH -> LOW)
    if (lastButtonState[i] == HIGH && currentState == LOW) {

      // Toggle LED state
      ledState[i] = !ledState[i];

      digitalWrite(ledPins[i], ledState[i]);

      delay(200);   // Simple debounce
    }

    lastButtonState[i] = currentState;
  }
}